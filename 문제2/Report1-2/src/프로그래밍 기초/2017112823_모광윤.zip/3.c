#include <stdio.h>

int main(void) {
	float x = 2.58f;
	double y = 8.567854L;


	printf("%f\n", x);
	printf("%f\n", y);
	printf("%f\n", 8.9654e+3);

	return 0;
	//2017112823_����
}